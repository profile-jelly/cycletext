16/01/2018

RELEASE (v1) data: 14,237 entries; 37,975 lexicalisations

